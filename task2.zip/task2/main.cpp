#include "xo_game.h"

using namespace std;



int main(){
    int choice;
    Player* players[2];
    players[0] = new Player (1, 'x');

    cout << "Welcome to FCAI X-O Game. :)\n";
    cout << "Press 1 if you want to play with computer: ";
    cin >> choice;
    if (choice != 1)
        players[1] = new Player (2, 'o');
    else
        //Player pointer points to child
        players[1] = new RandomPlayer ('o', 3);
    int choice2;
    cout<<"Chose a game: \n"
          "1- xo game(3x3)            2- Pyramic Tic Tac\n";
    cin>>choice2;
    if(choice2 == 1){
        GameManager x_o_game (new X_O_Board(), players);
        x_o_game.run();
        system ("pause");
    }else if(choice2 == 2){
        GameManager pyramic (new Pyramic(), players);
        pyramic.run();
        system ("pause");
    }

}