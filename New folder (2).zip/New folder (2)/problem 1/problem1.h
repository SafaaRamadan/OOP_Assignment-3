#ifndef PROBLEM1_PROBLEM1_H
#define PROBLEM1_PROBLEM1_H


#include <bits/stdc++.h>
using namespace std;


class LabelGenerator{
private:
    string prefix;
    int index;
protected:
    int current_line_index;
public:
    LabelGenerator(string Prefix, int Index);
    virtual string nextlabel();
};

class FileLabelGenerator: public LabelGenerator{
private:
    string file_path;
    vector<string>lines;
    ifstream file;
public:
    FileLabelGenerator(string prefix , int index , string path);
    string nextlabel() override;
};

#endif //PROBLEM1_PROBLEM1_H