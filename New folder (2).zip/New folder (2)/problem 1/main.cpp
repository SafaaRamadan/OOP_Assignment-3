#include "problem1.h"
using namespace std;


int main() {
    LabelGenerator figureNumbers("figure", 1);
    LabelGenerator pointNumbers("P", 0);
    cout <<"Figure numbers: ";
    for (int i = 0; i < 3; i++) {
        if(i == 2){
            cout<<figureNumbers.nextlabel();
            break;
        }
        cout <<figureNumbers.nextlabel()<<", ";
    }
    cout<<endl<<"Point numbers: ";
    for (int i = 0; i < 5 ; i++) {
        if(i == 4){
            cout <<pointNumbers.nextlabel();
            break;
        }
        cout <<pointNumbers.nextlabel()<<", ";
    }
    cout<<"\nMore Figures: ";
    for(int i = 0 ;i < 3 ;i++){
        if(i == 2){
            cout<<figureNumbers.nextlabel();
            break;
        }
        cout<<figureNumbers.nextlabel()<<", ";

    }

    FileLabelGenerator figureLabels ("Figure" , 1 , "C:\\Users\\Eng.Safi\\CLionProjects\\untitled9\\try");

    cout<<"\nfigure Labels:\n";
    for(int i = 0 ;i < 5 ; i++){
        cout<<figureLabels.nextlabel()<<endl;
    }
    return 0;
}