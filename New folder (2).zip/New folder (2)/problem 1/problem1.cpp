#include "problem1.h"


LabelGenerator::LabelGenerator(string Prefix, int Index):prefix(Prefix), index(Index){}

string LabelGenerator::nextlabel(){
    string label = prefix + " " +to_string(index);
    index++;
    return label;
}


FileLabelGenerator::FileLabelGenerator(string prefix, int index, string path): LabelGenerator(prefix,index),file_path(path){
    ifstream file(path);
    if(!file){
        cout<<"error";
        return;
    }

    string line;
    while(getline(file,line)){
        lines.push_back(line);
    }
    file.close();

    current_line_index = 0;
}
string FileLabelGenerator::nextlabel() {
    string generatedlabel = LabelGenerator::nextlabel();

    if(current_line_index < lines.size()){
        string next = generatedlabel + " " + lines[current_line_index];
        current_line_index++;
        return next;
    }else{
        current_line_index = 0;
        string next = generatedlabel + " " + lines[current_line_index];
        current_line_index++;
        return next;
    }

}