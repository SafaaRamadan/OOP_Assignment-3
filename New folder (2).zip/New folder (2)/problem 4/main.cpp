#include <iostream>
using namespace std;
const int SIZE = 10000;

template<class T>
class set{
private:
 T items[SIZE];
 int top;
public:
    set(): top(-1) {}

    void push(T value);
    T pop();
    int size();
    void print_set();
    T* toArray();
    bool operator==( set& other);
    bool operator!=( set& other);

    template<class U>
    friend ostream& operator<<(ostream& os , set<U>& st);
};
template<class T>
bool set<T>::operator==( set& other) {
    if (size() != other.size()) {
        return false;
    }

    for (int i = 0; i < size(); ++i) {
        if (items[i] != other.items[i]) {
            return false;
        }
    }

    return true;
}
template<class T>
bool set<T>::operator!=( set& other) {
    return !(*this == other);
}

template<class T>
void set<T>::push (T value){
    if(top == SIZE -1){
        cout<<"Set is full";
        return;
    }

    for(int i = 0 ; i <= top ; i++){
        if(items[i] == value){
            cout<<value << " is a member of the set.\n";
            return;
        }
    }

    items[++top] = value;
}

template<class T>
T set<T>::pop() {
    if(top == -1) {
        cout << "set is empty!!";
        return T();
    }
    return items[top--];
}


template<class T>
void set<T>::print_set(){
    for(int i = 0 ; i <= top ; i++){
        cout<<items[i]<<" ";
    }
}

template<class T>
int set<T>::size() {
    return top+1;
}


template<class U>
ostream& operator<<(ostream& os , set<U>& st){
    st.print_set();
    return os;
}


template<class T>
T* set<T> ::toArray(){
    T* newArray = new T[size()];

    for(int i = 0 ; i < size() ; i++){
        newArray[i] = items[i];
    }
    return newArray;
}


int main() {
    set<int>intset ,intset2;
    intset.push(10);
    intset.push(109);
    intset.push(109);
    intset.print_set();
    cout<<"\n1st set after removing last element:\n";
    intset.pop();
    intset.print_set();
    cout<<"\nNumber of items in the set: "<<intset.size();
    cout<<"\n";
    intset2.push(10);
    intset2.push(109);
    intset2.push(109);
    cout<<"2nd set:\n"<<intset2;
    cout<<"\nCheck if set 1 and 2 are equal or not:\n";
    if(intset != intset2){
        cout<<"sets are not equal\n";
    }else{
        cout<<"sets are equal\n";
    }
    set<string>stringset ,stringset2;
    stringset.push("Safaa");
    stringset.push("Ramadan");
    stringset.push("Abdou");
    cout<<"1st set:\n"<<stringset;
    cout<<"\nNumber of items in the set: "<<stringset.size();
    stringset2.push("Safaa");
    stringset2.push("Ramadan");
    stringset2.push("Abdou");
    cout<<"\n2nd set:\n"<<stringset2;
    cout<<"\nCheck if set 1 and 2 are equal or not:\n";
    if(stringset == stringset2){
        cout<<"sets are equal";
    }else{
        cout<<"sets are not equal";
    }


    string* ArrayOfString = stringset.toArray();
    cout<<"\nElements in the array of string:  ";
    for(int i = 0 ; i < stringset.size() ; i++){
        cout<<ArrayOfString[i]<<" ";
    }

    delete[] ArrayOfString;
    return 0;
}
