#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <cctype>

using namespace std;

string cleanText(const string& input) {
    string cleanedText;
    for (char c : input) {
        if (isalnum(c) || c == '-') {
            cleanedText += tolower(c);
        }
        else if (isspace(c)) {
            cleanedText += ' ';
        }
    }
    return cleanedText;
}

int main() {
    string filename;
    cout << "Enter the filename: ";
    cin >> filename;

    ifstream inputFile(filename);
    if (!inputFile.is_open()) {
        cerr << "Error opening file!" << endl;
        return 1;
    }

    map<string, int> frequencyTable;
    string word;

    while (inputFile >> word) {
        frequencyTable[cleanText(word)]++;
    }

    for (auto & entry : frequencyTable) {
        cout << entry.first << ": " << entry.second << endl;
    }

    return 0;
}
