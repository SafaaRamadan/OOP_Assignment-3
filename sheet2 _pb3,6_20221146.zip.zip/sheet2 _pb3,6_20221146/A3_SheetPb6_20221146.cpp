
#include <iostream>
using namespace std;
const int rows = 20;
const int cols = 20;
class Universe {
private:
	
	bool grid[rows][cols];
public:
	Universe() {
		initialize();
	}
	void initialize() {
		srand(time(0));
		for (int i = 0; i < rows; ++i) {
			for (int j = 0; j < cols; ++j) {
				grid[i][j] = rand() % 2;
			}
		}
	}
	void reset() {
		for (int i = 0; i < 20; ++i) {
			for (int j = 0; j < 20; ++j) {
				grid[i][j] = 0;
			}
		}
	}

	int count_neighbors(int x, int y) {
		int count = 0;
		for (int i = -1; i <= 1; ++i) {
			for (int j = -1; j <= 1; ++j) {
				if (i == 0 && j == 0) continue; // Skip the basic cell, dont count it 
				int ni = x + i;
				int nj = y + j;
				if (ni >= 0 && ni < rows && nj >= 0 && nj < cols && grid[ni][nj]) {
					count++;
				}
			}
		}
		return count;
	}
	void display() {

		
		for (int i = 0; i < rows; ++i) {
			for (int j = 0; j < cols; ++j) {
				cout << grid[i][j]; // Alive cells are displayed as "O", dead cells as space
			}
			cout << endl;
			
		}
	}

	void next_generation() {
		bool newGrid[rows][cols];

		for (int i = 0; i < rows; ++i) {
			for (int j = 0; j < cols; ++j) {
				int neighbors = count_neighbors(i, j);
				if (grid[i][j]) {
					// Any live cell with fewer than two live neighbors dies
					// Any live cell with more than three live neighbors dies
					newGrid[i][j] = (neighbors == 2 || neighbors == 3);
				}
				else {
					// Any dead cell with exactly three live neighbors becomes a live cell
					newGrid[i][j] = (neighbors == 3);
				}
			}
		}

		// Update the grid with newGrid
		for (int i = 0; i < rows; ++i) {
			for (int j = 0; j < cols; ++j) {
				grid[i][j] = newGrid[i][j];
			}
		}

		// Display the updated grid
		display();
		cout << endl;
	}

	void run(int generations) {
		for (int gen = 0; gen < generations; ++gen) {
			display();
			next_generation();
			cout << endl;
		}
	}

};
int main()
{
	Universe game;
	game.run(2);
	return 0;
}